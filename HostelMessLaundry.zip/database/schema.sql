-- Hostel Mess and Laundry Management System : MySQL schema + sample data
-- Run:  mysql -u root -p < database/schema.sql

DROP DATABASE IF EXISTS hostel_db;
CREATE DATABASE hostel_db CHARACTER SET utf8mb4;
USE hostel_db;

-- Table 2 (created first because Students references it)
CREATE TABLE MealPlans (
    plan_id      INT AUTO_INCREMENT PRIMARY KEY,
    plan_name    VARCHAR(40)  NOT NULL UNIQUE,
    monthly_fee  DECIMAL(8,2) NOT NULL CHECK (monthly_fee >= 0)
);

-- Table 1
CREATE TABLE Students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(50) NOT NULL,
    room_no    VARCHAR(10) NOT NULL,
    phone      VARCHAR(15),
    email      VARCHAR(60),
    plan_id    INT NOT NULL,
    CONSTRAINT fk_student_plan FOREIGN KEY (plan_id)
        REFERENCES MealPlans(plan_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Table 3
CREATE TABLE MealAttendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id    INT         NOT NULL,
    date          DATE        NOT NULL,
    meal_type     VARCHAR(15) NOT NULL CHECK (meal_type IN ('Breakfast','Lunch','Dinner')),
    status        VARCHAR(10) NOT NULL CHECK (status IN ('Present','Absent')),
    CONSTRAINT fk_att_student FOREIGN KEY (student_id)
        REFERENCES Students(student_id) ON DELETE CASCADE,
    CONSTRAINT uq_att UNIQUE (student_id, date, meal_type)   -- one record per student/day/meal
);

-- Table 4
CREATE TABLE LaundryOrders (
    order_id      INT AUTO_INCREMENT PRIMARY KEY,
    student_id    INT         NOT NULL,
    date_given    DATE        NOT NULL,
    date_returned DATE        NULL,
    total_clothes INT         NOT NULL CHECK (total_clothes > 0),
    status        VARCHAR(15) NOT NULL DEFAULT 'Pending'
                  CHECK (status IN ('Pending','Washing','Returned')),
    CONSTRAINT fk_laundry_student FOREIGN KEY (student_id)
        REFERENCES Students(student_id) ON DELETE CASCADE
);

-- Table 5
CREATE TABLE Payments (
    payment_id   INT AUTO_INCREMENT PRIMARY KEY,
    student_id   INT          NOT NULL,
    amount       DECIMAL(8,2) NOT NULL CHECK (amount > 0),
    month        VARCHAR(15)  NOT NULL,          -- stored as YYYY-MM, e.g. 2026-10
    payment_date DATE         NOT NULL,
    CONSTRAINT fk_pay_student FOREIGN KEY (student_id)
        REFERENCES Students(student_id) ON DELETE CASCADE
);

-- ---------------- Sample data ----------------
INSERT INTO MealPlans (plan_name, monthly_fee) VALUES
 ('Full Plan', 9000.00), ('Lunch and Dinner', 7000.00), ('Dinner Only', 4000.00);

INSERT INTO Students (name, room_no, phone, email, plan_id) VALUES
 ('Ali Raza',     'A-101', '03001234567', 'ali@example.com',   1),
 ('Sara Khan',    'A-102', '03011234567', 'sara@example.com',  2),
 ('Hamza Ahmed',  'B-201', '03021234567', 'hamza@example.com', 3),
 ('Fatima Noor',  'B-202', '03031234567', 'fatima@example.com',1);

INSERT INTO MealAttendance (student_id, date, meal_type, status) VALUES
 (1, CURDATE(), 'Breakfast', 'Present'), (1, CURDATE(), 'Lunch', 'Present'), (1, CURDATE(), 'Dinner', 'Absent'),
 (2, CURDATE(), 'Lunch', 'Present'),     (2, CURDATE(), 'Dinner', 'Present'),
 (3, CURDATE(), 'Dinner', 'Present');

INSERT INTO LaundryOrders (student_id, date_given, date_returned, total_clothes, status) VALUES
 (1, CURDATE() - INTERVAL 3 DAY, CURDATE() - INTERVAL 1 DAY, 8, 'Returned'),
 (2, CURDATE() - INTERVAL 1 DAY, NULL, 5, 'Washing'),
 (4, CURDATE(), NULL, 10, 'Pending');

INSERT INTO Payments (student_id, amount, month, payment_date) VALUES
 (1, 9000.00, DATE_FORMAT(CURDATE(), '%Y-%m'), CURDATE()),
 (2, 3000.00, DATE_FORMAT(CURDATE(), '%Y-%m'), CURDATE());
