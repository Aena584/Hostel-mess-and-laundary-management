// ---------- Helpers ----------
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n) => "Rs. " + Number(n || 0).toLocaleString("en-PK", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
const today = () => new Date().toISOString().slice(0, 10);
const thisMonth = () => today().slice(0, 7);

async function api(url, method = "GET", body) {
  const res = await fetch("/api" + url, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new Error(data?.error || "Request failed (" + res.status + ")");
  return data;
}

function toast(msg, isErr = false) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast" + (isErr ? " err" : "");
  t.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.hidden = true), 3000);
}

// Run an action, show error toast on failure
async function run(fn, okMsg) {
  try { await fn(); if (okMsg) toast(okMsg); }
  catch (e) { toast(e.message, true); }
}

// ---------- Modal form ----------
// fields: [{name, label, type, value, options:[{value,label}], required}]
function openForm(title, fields, onSave) {
  $("modalTitle").textContent = title;
  $("modalFields").innerHTML = fields.map((f) => {
    const id = "f_" + f.name;
    const input = f.type === "select"
      ? `<select id="${id}">${f.options.map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(f.value) ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`
      : `<input id="${id}" type="${f.type || "text"}" value="${esc(f.value ?? "")}" ${f.required ? "required" : ""} ${f.min !== undefined ? `min="${f.min}"` : ""} ${f.step ? `step="${f.step}"` : ""}>`;
    return `<div class="field"><label for="${id}">${esc(f.label)}${f.required ? " *" : ""}</label>${input}</div>`;
  }).join("");
  $("modal").hidden = false;
  $("modalForm").onsubmit = async (e) => {
    e.preventDefault();
    const values = {};
    fields.forEach((f) => (values[f.name] = $("f_" + f.name).value));
    try { await onSave(values); $("modal").hidden = true; }
    catch (err) { toast(err.message, true); }
  };
}
$("modalCancel").onclick = () => ($("modal").hidden = true);

// ---------- Navigation ----------
const loaders = {
  dashboard: loadDashboard, students: loadStudents, plans: loadPlans,
  attendance: loadAttendance, laundry: loadLaundry, payments: loadPayments,
};
document.querySelectorAll("#nav button").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll("#nav button").forEach((x) => x.classList.toggle("active", x === b));
    document.querySelectorAll(".page").forEach((p) => (p.hidden = p.id !== "page-" + b.dataset.page));
    run(loaders[b.dataset.page]);
  };
});

// ---------- Dashboard ----------
async function loadDashboard() {
  const s = await api("/stats");
  const cards = [
    ["Students", s.students], ["Meal Plans", s.plans], ["Meals Eaten Today", s.mealsToday],
    ["Laundry Not Returned", s.openLaundry], ["Collected This Month", money(s.collectedThisMonth)],
  ];
  $("statCards").innerHTML = cards.map(([l, n]) => `<div class="card"><div class="num">${esc(n)}</div><div class="lbl">${l}</div></div>`).join("");
}

// ---------- Meal plans ----------
let plansCache = [];
async function loadPlans() {
  plansCache = await api("/plans");
  $("planRows").innerHTML = plansCache.length ? plansCache.map((p) => `
    <tr><td>${p.planId}</td><td>${esc(p.planName)}</td><td>${money(p.monthlyFee)}</td><td>${p.students}</td>
    <td><button class="small" onclick="editPlan(${p.planId})">Edit</button>
        <button class="small danger" onclick="deletePlan(${p.planId})">Delete</button></td></tr>`).join("")
    : `<tr><td class="empty" colspan="5">No meal plans yet.</td></tr>`;
}
const planFields = (p = {}) => [
  { name: "planName", label: "Plan name", value: p.planName, required: true },
  { name: "monthlyFee", label: "Monthly fee (Rs.)", type: "number", value: p.monthlyFee, required: true, min: 0, step: "0.01" },
];
$("addPlanBtn").onclick = () => openForm("Add Meal Plan", planFields(), async (v) => {
  await api("/plans", "POST", { planName: v.planName, monthlyFee: Number(v.monthlyFee) });
  toast("Plan added"); loadPlans();
});
window.editPlan = (id) => {
  const p = plansCache.find((x) => x.planId === id);
  openForm("Edit Meal Plan", planFields(p), async (v) => {
    await api("/plans/" + id, "PUT", { planName: v.planName, monthlyFee: Number(v.monthlyFee) });
    toast("Plan updated"); loadPlans();
  });
};
window.deletePlan = (id) => {
  if (!confirm("Delete this meal plan?")) return;
  run(async () => { await api("/plans/" + id, "DELETE"); await loadPlans(); }, "Plan deleted");
};

// ---------- Students ----------
let studentsCache = [];
async function fetchStudents(q = "") {
  studentsCache = await api("/students" + (q ? "?search=" + encodeURIComponent(q) : ""));
  return studentsCache;
}
async function loadStudents() {
  const rows = await fetchStudents($("studentSearch").value.trim());
  $("studentRows").innerHTML = rows.length ? rows.map((s) => `
    <tr><td>${s.studentId}</td><td>${esc(s.name)}</td><td>${esc(s.roomNo)}</td><td>${esc(s.phone)}</td>
    <td>${esc(s.email)}</td><td>${esc(s.planName)}</td>
    <td><button class="small" onclick="editStudent(${s.studentId})">Edit</button>
        <button class="small danger" onclick="deleteStudent(${s.studentId})">Delete</button></td></tr>`).join("")
    : `<tr><td class="empty" colspan="7">No students found.</td></tr>`;
}
$("studentSearch").oninput = () => run(loadStudents);

async function studentFields(s = {}) {
  const plans = await api("/plans");
  if (!plans.length) throw new Error("Please add a meal plan first.");
  return [
    { name: "name", label: "Full name", value: s.name, required: true },
    { name: "roomNo", label: "Room number", value: s.roomNo, required: true },
    { name: "phone", label: "Phone", value: s.phone },
    { name: "email", label: "Email", type: "email", value: s.email },
    { name: "planId", label: "Meal plan", type: "select", value: s.planId,
      options: plans.map((p) => ({ value: p.planId, label: `${p.planName} (${money(p.monthlyFee)})` })) },
  ];
}
const studentBody = (v) => ({ name: v.name, roomNo: v.roomNo, phone: v.phone, email: v.email, planId: Number(v.planId) });
$("addStudentBtn").onclick = () => run(async () => {
  openForm("Add Student", await studentFields(), async (v) => {
    await api("/students", "POST", studentBody(v)); toast("Student added"); loadStudents();
  });
});
window.editStudent = (id) => run(async () => {
  const s = studentsCache.find((x) => x.studentId === id);
  openForm("Edit Student", await studentFields(s), async (v) => {
    await api("/students/" + id, "PUT", studentBody(v)); toast("Student updated"); loadStudents();
  });
});
window.deleteStudent = (id) => {
  if (!confirm("Delete this student? Their attendance, laundry and payment records will also be deleted.")) return;
  run(async () => { await api("/students/" + id, "DELETE"); await loadStudents(); }, "Student deleted");
};

// ---------- Meal attendance ----------
const MEALS = ["Breakfast", "Lunch", "Dinner"];
async function loadAttendance() {
  if (!$("attDate").value) $("attDate").value = today();
  const date = $("attDate").value;
  const [students, records] = await Promise.all([fetchStudents(), api("/attendance?date=" + date)]);
  const map = {};
  records.forEach((r) => (map[r.studentId + "|" + r.mealType] = r.status));
  $("attRows").innerHTML = students.length ? students.map((s) => `
    <tr><td>${esc(s.name)}</td><td>${esc(s.roomNo)}</td>
    ${MEALS.map((m) => {
      const cur = map[s.studentId + "|" + m] || "";
      return `<td><select onchange="markMeal(${s.studentId}, '${m}', this)">
        <option value="" ${cur === "" ? "selected" : ""}>—</option>
        <option ${cur === "Present" ? "selected" : ""}>Present</option>
        <option ${cur === "Absent" ? "selected" : ""}>Absent</option></select></td>`;
    }).join("")}</tr>`).join("")
    : `<tr><td class="empty" colspan="5">No students yet.</td></tr>`;
}
$("attDate").onchange = () => run(loadAttendance);
window.markMeal = (studentId, mealType, sel) => run(() =>
  api("/attendance", "POST", { studentId, date: $("attDate").value, mealType, status: sel.value }), "Saved");

// ---------- Laundry ----------
async function loadLaundry() {
  const f = $("laundryFilter").value;
  const rows = await api("/laundry" + (f ? "?status=" + f : ""));
  $("laundryRows").innerHTML = rows.length ? rows.map((o) => `
    <tr><td>${o.orderId}</td><td>${esc(o.studentName)}</td><td>${esc(o.roomNo)}</td>
    <td>${o.dateGiven}</td><td>${o.dateReturned || "—"}</td><td>${o.totalClothes}</td>
    <td><span class="badge b-${o.status}">${o.status}</span></td>
    <td><select onchange="setLaundry(${o.orderId}, this.value)">
      ${["Pending", "Washing", "Returned"].map((s) => `<option ${s === o.status ? "selected" : ""}>${s}</option>`).join("")}</select>
      <button class="small danger" onclick="deleteLaundry(${o.orderId})">Delete</button></td></tr>`).join("")
    : `<tr><td class="empty" colspan="8">No laundry orders.</td></tr>`;
}
$("laundryFilter").onchange = () => run(loadLaundry);
$("addLaundryBtn").onclick = () => run(async () => {
  const students = await fetchStudents();
  if (!students.length) throw new Error("Please add a student first.");
  openForm("New Laundry Order", [
    { name: "studentId", label: "Student", type: "select", options: students.map((s) => ({ value: s.studentId, label: `${s.name} (${s.roomNo})` })) },
    { name: "dateGiven", label: "Date given", type: "date", value: today(), required: true },
    { name: "totalClothes", label: "Number of clothes", type: "number", value: 1, min: 1, required: true },
  ], async (v) => {
    await api("/laundry", "POST", { studentId: Number(v.studentId), dateGiven: v.dateGiven, totalClothes: Number(v.totalClothes) });
    toast("Laundry order added"); loadLaundry();
  });
});
window.setLaundry = (id, status) => run(async () => { await api(`/laundry/${id}/status`, "PUT", { status }); await loadLaundry(); }, "Status updated");
window.deleteLaundry = (id) => {
  if (!confirm("Delete this laundry order?")) return;
  run(async () => { await api("/laundry/" + id, "DELETE"); await loadLaundry(); }, "Order deleted");
};

// ---------- Payments & billing ----------
async function loadPayments() {
  if (!$("billMonth").value) $("billMonth").value = thisMonth();
  const month = $("billMonth").value;
  const [bill, pays] = await Promise.all([api("/bill?month=" + month), api("/payments?month=" + month)]);
  let tFee = 0, tPaid = 0, tBal = 0;
  $("billRows").innerHTML = bill.length ? bill.map((b) => {
    tFee += b.fee; tPaid += b.paid; tBal += b.balance;
    const st = b.balance <= 0 ? "Paid" : b.paid > 0 ? "Partial" : "Unpaid";
    return `<tr><td>${esc(b.name)}</td><td>${esc(b.roomNo)}</td><td>${esc(b.planName)}</td><td>${b.mealsEaten}</td>
      <td>${money(b.fee)}</td><td>${money(b.paid)}</td><td>${money(b.balance)}</td><td><span class="badge b-${st}">${st}</span></td></tr>`;
  }).join("") : `<tr><td class="empty" colspan="8">No students yet.</td></tr>`;
  $("billFoot").innerHTML = `<tr><td colspan="4">Total</td><td>${money(tFee)}</td><td>${money(tPaid)}</td><td>${money(tBal)}</td><td></td></tr>`;
  $("payRows").innerHTML = pays.length ? pays.map((p) => `
    <tr><td>${p.paymentId}</td><td>${esc(p.studentName)}</td><td>${esc(p.month)}</td><td>${money(p.amount)}</td><td>${p.paymentDate}</td>
    <td><button class="small danger" onclick="deletePayment(${p.paymentId})">Delete</button></td></tr>`).join("")
    : `<tr><td class="empty" colspan="6">No payments for this month.</td></tr>`;
}
$("billMonth").onchange = () => run(loadPayments);
$("printBtn").onclick = () => window.print();
$("addPaymentBtn").onclick = () => run(async () => {
  const students = await fetchStudents();
  if (!students.length) throw new Error("Please add a student first.");
  openForm("Record Payment", [
    { name: "studentId", label: "Student", type: "select", options: students.map((s) => ({ value: s.studentId, label: `${s.name} (${s.roomNo})` })) },
    { name: "amount", label: "Amount (Rs.)", type: "number", min: 1, step: "0.01", required: true },
    { name: "month", label: "Month", type: "month", value: $("billMonth").value || thisMonth(), required: true },
    { name: "paymentDate", label: "Payment date", type: "date", value: today(), required: true },
  ], async (v) => {
    await api("/payments", "POST", { studentId: Number(v.studentId), amount: Number(v.amount), month: v.month, paymentDate: v.paymentDate });
    toast("Payment recorded"); loadPayments();
  });
});
window.deletePayment = (id) => {
  if (!confirm("Delete this payment record?")) return;
  run(async () => { await api("/payments/" + id, "DELETE"); await loadPayments(); }, "Payment deleted");
};

// ---------- Start ----------
run(loadDashboard);
